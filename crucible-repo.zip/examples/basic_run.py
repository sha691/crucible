#!/usr/bin/env python3
"""
Crucible — Basic Demo Run

This script demonstrates the full Crucible pipeline:
1. Generate a realistic enterprise AI simulation
2. Detect patterns via the Forge
3. Create capital assets with ROI calculations
4. Generate the Amortization Ledger report
5. Export an interactive HTML dashboard
"""

import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from capture import InteractionCapture
from forge import DistillationEngine
from ledger import AmortizationLedger
from simulator import generate_simulation
from dashboard import generate_dashboard


def main():
    print("=" * 60)
    print("CRUCIBLE — AI Capitalization Engine")
    print("=" * 60)

    # Step 1: Generate simulation
    print("
[1] Generating 30-day enterprise simulation...")
    capture = generate_simulation(days=30, seed=42)
    summary = capture.summary()
    print(f"    Captured {summary['total_interactions']:,} interactions")
    print(f"    Total cost: ${summary['total_cost']:,.2f}")
    print(f"    Users: {summary['unique_users']} | Tasks: {summary['unique_tasks']} | Depts: {summary['unique_departments']}")

    # Step 2: Detect patterns
    print("
[2] Running the Forge — pattern detection...")
    engine = DistillationEngine(capture)
    patterns = engine.detect_patterns()
    print(f"    Detected {len(patterns)} repeatable patterns")

    # Step 3: Forge assets
    print("
[3] Forging capital assets...")
    assets = engine.forge_assets(deploy_all=True)
    print(f"    Forged {len(assets)} assets:")
    type_counts = {}
    for a in assets:
        type_counts[a.asset_type] = type_counts.get(a.asset_type, 0) + 1
    for t, c in sorted(type_counts.items()):
        print(f"      - {t}: {c}")

    # Step 4: Generate ledger report
    print("
[4] Generating Amortization Ledger...")
    ledger = AmortizationLedger(assets, capture.interactions, patterns)
    report = ledger.generate_report()

    print(f"
{'=' * 60}")
    print("EXECUTIVE SUMMARY")
    print(f"{'=' * 60}")
    print(f"Total Interactions:      {report.total_interactions:,}")
    print(f"30-Day AI Spend:         ${report.total_spend:,.2f}")
    print(f"Assets Deployed:         {report.assets_deployed}")
    print(f"CapEx Invested:          ${report.capex_invested:,.2f}")
    print(f"Monthly OpEx Avoided:    ${report.opex_avoided:,.2f}")
    print(f"Net Monthly Savings:     ${report.net_savings:,.2f}")
    print(f"Daily Run Rate Before:   ${report.run_rate_before:,.2f}")
    print(f"Daily Run Rate After:    ${report.run_rate_after:,.2f}")
    print(f"Efficiency Gain:         {report.efficiency_score}%")
    print(f"Asset Library Value:     ${report.asset_library_value:,.2f}")
    print(f"{'=' * 60}")

    # Step 5: Generate dashboard
    print("
[5] Generating interactive dashboard...")
    dashboard_path = generate_dashboard(
        interactions=capture.interactions,
        assets=assets,
        report=report,
        output_path="crucible_dashboard.html"
    )
    print(f"    Dashboard saved to: {dashboard_path}")
    print("    Open it in any browser to view.")

    print("
" + "=" * 60)
    print("Done. Your AI usage has been capitalized.")
    print("=" * 60)


if __name__ == "__main__":
    main()
