# Crucible Architecture

## Overview

Crucible is composed of four primary subsystems, each with a distinct responsibility in the capitalization pipeline.

```
┌─────────────────────────────────────────────────────────────────┐
│                         ENTERPRISE                              │
│  Employees, Agents, CI/CD, Support Tools, Marketing Platforms   │
└───────────────────────────┬─────────────────────────────────────┘
                            │
                    ┌───────▼────────┐
                    │   The Crucible  │
                    │   (Capture)     │
                    └───────┬────────┘
                            │
                    ┌───────▼────────┐
                    │    The Forge    │
                    │  (Distillation) │
                    └───────┬────────┘
                            │
                    ┌───────▼────────┐
                    │   The Ledger    │
                    │ (Amortization)  │
                    └───────┬────────┘
                            │
                    ┌───────▼────────┐
                    │   Dashboard     │
                    │  (Visualization)│
                    └─────────────────┘
```

## 1. The Crucible (Capture)

**Responsibility:** Ingest and index every AI interaction with forensic detail.

**Inputs:**
- API proxy logs (OpenAI, Anthropic, DeepSeek, etc.)
- Browser extension telemetry
- SDK wrappers (drop-in replacements for provider SDKs)
- Manual CSV/JSON imports

**Data Model:**
Each `AIInteraction` captures:
- Identity: user, department, timestamp
- Technical: model, tokens, cost
- Semantic: task_type (inferred or tagged), prompt_summary
- Quality: output_accepted (human validation signal)
- Traceability: context_hash (for deduplication and clustering)

**Indexing:**
- By user_id for individual behavior analysis
- By task_type for pattern detection
- By department for chargeback and budgeting
- By context_hash for deduplication

## 2. The Forge (Distillation)

**Responsibility:** Detect repeatable patterns and propose or deploy capital assets.

**Pattern Detection:**
Groups interactions by `(department, task_type)` and qualifies as a pattern if frequency exceeds the task-specific threshold defined in `TASK_SIGNATURES`.

**Asset Types:**

| Type | Creation Method | Runtime Cost | Best For |
|------|----------------|--------------|----------|
| `template` | Prompt engineering + validation | ~2% of original | Repetitive text generation |
| `script` | Code generation + testing | ~1% of original | Data processing, analysis |
| `micro_model` | Fine-tuning on captured data | ~5% of original | Classification, narrow reasoning |
| `workflow` | Orchestration (n8n/Zapier/Temporal) | ~3% of original | Multi-step business processes |

**Economics Model:**
```
creation_cost = forge_cost + (historical_spend * 0.20)
monthly_savings = daily_freq * 30 * (original_cost - runtime_cost) * replacement_rate
payback_days = creation_cost / (monthly_savings / 30)
remaining_value = monthly_savings * 12
```

## 3. The Ledger (Amortization)

**Responsibility:** Convert raw usage and asset data into CFO-friendly financial reporting.

**Key Metrics:**
- **Run Rate Before/After:** Daily AI spend before and after asset deployment
- **Efficiency Score:** Percentage reduction in run rate
- **Asset Library Value:** Sum of all asset remaining values (12-month horizon)
- **Net Monthly Savings:** OpEx avoided minus CapEx amortized

**Depreciation:**
Straight-line over 12 months. Each asset's book value declines predictably while its cumulative savings grow.

## 4. Dashboard (Visualization)

**Responsibility:** Present capitalization impact in a single-page interactive view.

**Charts:**
- Daily spend trend (line)
- Department breakdown (doughnut)
- Model comparison (bar)
- CapEx vs OpEx shift (grouped bar)
- Top users (bar)
- Task distribution (polar area)

**Tables:**
- Asset inventory with ROI per asset
- Detected patterns before capitalization

## Data Flow

```
Raw Interactions
      │
      ▼
┌─────────────┐
│  Crucible   │ ──► Indexed storage (in-memory for PoC, PostgreSQL for prod)
└─────────────┘
      │
      ▼
┌─────────────┐
│    Forge    │ ──► Pattern detection ──► Asset proposals
└─────────────┘
      │
      ▼
┌─────────────┐
│   Ledger    │ ──► Financial calculations ──► Report object
└─────────────┘
      │
      ▼
┌─────────────┐
│  Dashboard  │ ──► HTML file with embedded Chart.js
└─────────────┘
```

## Production Considerations

### Capture Layer
- **API Proxy:** Deploy as sidecar or gateway (Envoy, Nginx, custom Go service)
- **Browser Extension:** Chrome/Firefox extension for web-based AI tools
- **SDK Wrapper:** Python/JS packages that wrap provider SDKs with telemetry

### Storage
- **PostgreSQL:** Relational data (users, departments, assets)
- **TimescaleDB:** Time-series metrics (daily spend, token counts)
- **Redis:** Rate limiting, session cache, real-time counters

### Forge Automation
- **Template engine:** Jinja2 with validation schemas
- **Script runner:** Sandboxed Python execution (Pyodide, Firecracker)
- **Fine-tuning pipeline:** Modal, RunPod, or self-hosted GPU cluster
- **Workflow engine:** Temporal, n8n, or custom DAG executor

### Integration Points
- **SSO:** Auth0, WorkOS, Azure AD
- **Alerts:** Slack, Teams, PagerDuty
- **ERP:** NetSuite, SAP (for CapEx line items)
- **SIEM:** Splunk, Sentinel (for audit trails)
