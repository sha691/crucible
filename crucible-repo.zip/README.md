# Crucible

> **Turn consumable AI into permanent capital.**

Crucible is an AI capitalization engine for enterprises. Instead of treating LLM usage as a recurring operating expense (OpEx), Crucible captures, analyzes, and forges your team's AI interactions into reusable capital assets — templates, scripts, micro-models, and workflows — that permanently reduce your AI run rate.

---

## The Problem

- **AI costs are spiking** as agentic workflows and multi-step reasoning consume exponentially more tokens.
- **Chinese models drove API prices to near-zero**, but volume exploded. The bill isn't the problem — the *waste* is.
- **Every AI call is a consumable.** You rent intelligence by the sip and retain nothing.
- **CFOs hate AI budgets** because they are variable, unpredictable, and grow faster than revenue.

## The Solution

Crucible inverts the accounting:

| Before | After |
|--------|-------|
| OpEx: $50k/month in API tokens | CapEx: $15k one-time to build assets |
| Run rate scales with usage | Run rate *decays* as assets compound |
| $0 retained value | Asset library with book value & depreciation |
| Shadow AI everywhere | Captured patterns become sanctioned infrastructure |

## How It Works

```
┌─────────────┐     ┌──────────────┐     ┌─────────────┐     ┌──────────────┐
│   Crucible  │────▶│    Forge     │────▶│   Ledger    │────▶│   Dashboard  │
│   (Capture) │     │  (Distill)   │     │ (Amortize)  │     │  (Visualize) │
└─────────────┘     └──────────────┘     └─────────────┘     └──────────────┘
```

1. **The Crucible** intercepts every AI interaction across your enterprise.
2. **The Forge** detects repeatable patterns and proposes capital assets.
3. **The Ledger** converts everything into CFO-friendly CapEx/OpEx reporting.
4. **The Dashboard** shows real-time asset value, payback periods, and run-rate decay.

## Quick Start

```bash
# Clone
git clone https://github.com/your-org/crucible.git
cd crucible

# Install
pip install -r requirements.txt

# Run the simulation
python examples/basic_run.py

# Generate the dashboard
python -m src.dashboard
```

## Example Output

```
==================================================
THE CRUCIBLE — CAPITALIZATION REPORT
==================================================
Total Interactions:      4,315
30-Day AI Spend:         $827.61
Assets Deployed:         19
CapEx Invested:          $1,915.52
Monthly OpEx Avoided:    $648.86
Daily Run Rate Before:   $27.59
Daily Run Rate After:    $5.92
Efficiency Gain:         78.5%
Asset Library Value:     $7,786.14
==================================================
```

## Architecture

See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for the full system design.

## Asset Types

| Type | What It Is | Example |
|------|-----------|---------|
| **Template** | Parameterized prompt with validation | Marketing email generator |
| **Script** | Automation replacing the AI loop | Data analysis pipeline |
| **Micro-Model** | Fine-tuned model for narrow task | Support ticket classifier |
| **Workflow** | Multi-step orchestration | Customer response → CRM update |

## Philosophy

> *"Stop renting intelligence. Start owning it."*

Crucible doesn't block AI. It doesn't route to cheaper models. It **harvests** your usage and **compounds** it into infrastructure that pays dividends.

## License

MIT — see [LICENSE](LICENSE).
