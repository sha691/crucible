"""Tests for the Crucible forge module."""

import datetime
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from capture import AIInteraction, InteractionCapture
from forge import DistillationEngine


def make_interaction(user, dept, task, model, cost, accepted=True):
    return AIInteraction(
        id=f"INT-{user}-{task}",
        timestamp=datetime.datetime.now(),
        user_id=user,
        user_name=user,
        department=dept,
        task_type=task,
        model=model,
        input_tokens=1000,
        output_tokens=500,
        cost_usd=cost,
        prompt_summary=f"{task} test",
        output_accepted=accepted,
        context_hash=f"ctx_{dept}_{task}"
    )


def test_pattern_detection():
    capture = InteractionCapture()

    # Inject 10 email_draft interactions in Marketing (above threshold of 8)
    for i in range(10):
        capture.ingest(make_interaction(f"user{i}", "Marketing", "email_draft", "GPT-6", 0.15))

    engine = DistillationEngine(capture)
    patterns = engine.detect_patterns()

    assert "Marketing:email_draft" in patterns
    assert patterns["Marketing:email_draft"]["frequency"] == 10


def test_asset_forge():
    capture = InteractionCapture()

    for i in range(10):
        capture.ingest(make_interaction(f"user{i}", "Marketing", "email_draft", "GPT-6", 0.15))

    engine = DistillationEngine(capture)
    engine.detect_patterns()
    assets = engine.forge_assets(deploy_all=True)

    assert len(assets) == 1
    assert assets[0].asset_type == "template"
    assert assets[0].status == "deployed"
    assert assets[0].payback_days > 0
