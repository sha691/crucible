"""Tests for the Crucible capture module."""

import datetime
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from capture import AIInteraction, InteractionCapture


def test_ingest_and_query():
    capture = InteractionCapture()

    inter = AIInteraction(
        id="INT-00001",
        timestamp=datetime.datetime.now(),
        user_id="alice",
        user_name="Alice Chen",
        department="Engineering",
        task_type="code_review",
        model="GPT-6",
        input_tokens=4000,
        output_tokens=2000,
        cost_usd=0.27,
        prompt_summary="code review #1",
        output_accepted=True,
        context_hash="ctx_eng_1234"
    )

    capture.ingest(inter)

    assert len(capture.interactions) == 1
    assert len(capture.get_by_user("alice")) == 1
    assert len(capture.get_by_task("code_review")) == 1
    assert len(capture.get_by_department("Engineering")) == 1
    assert len(capture.get_by_user("bob")) == 0

    summary = capture.summary()
    assert summary["total_interactions"] == 1
    assert summary["total_cost"] == 0.27


def test_empty_capture():
    capture = InteractionCapture()
    assert capture.summary() == {}
    assert capture.get_by_user("anyone") == []
