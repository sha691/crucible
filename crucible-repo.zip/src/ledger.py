"""
The Ledger — CapEx / OpEx Amortization & Reporting

Converts raw AI usage and forged assets into CFO-friendly financial metrics:
- CapEx vs OpEx breakdown
- Run-rate calculations
- Asset depreciation & remaining value
- Efficiency scores
"""

from dataclasses import dataclass
from typing import List, Dict

from .capture import AIInteraction
from .forge import Asset


@dataclass
class FoundryReport:
    """Executive summary of capitalization impact."""
    total_interactions: int
    total_spend: float
    captured_patterns: int
    assets_proposed: int
    assets_deployed: int
    opex_avoided: float
    capex_invested: float
    net_savings: float
    run_rate_before: float
    run_rate_after: float
    efficiency_score: float
    asset_library_value: float


class AmortizationLedger:
    """
    The Ledger. Tracks the financial transformation from consumable OpEx
    to capitalized infrastructure with proper depreciation schedules.
    """

    def __init__(self, assets: List[Asset], interactions: List[AIInteraction], patterns: Dict):
        self.assets = assets
        self.interactions = interactions
        self.patterns = patterns

    def generate_report(self) -> FoundryReport:
        total_spend = sum(i.cost_usd for i in self.interactions)
        capex = sum(a.creation_cost for a in self.assets)
        opex_avoided = sum(a.monthly_savings for a in self.assets)

        # Pattern spend = what was historically spent on tasks that now have assets
        pattern_spend = sum(p['total_spent'] for p in self.patterns.values())

        run_rate_before = total_spend / 30

        # After: subtract avoided pattern spend, add minimal asset runtime cost
        asset_runtime_monthly = sum(
            a.estimated_daily_calls_replaced * 30 * a.avg_cost_per_call_before * 0.02
            for a in self.assets
        )
        avoided_daily = (pattern_spend / 30) * 0.80
        run_rate_after = run_rate_before - avoided_daily + (asset_runtime_monthly / 30)
        # Floor: even perfect capitalization can't eliminate 100% of spend
        run_rate_after = max(run_rate_after, total_spend * 0.05 / 30)

        return FoundryReport(
            total_interactions=len(self.interactions),
            total_spend=round(total_spend, 2),
            captured_patterns=len(self.assets),
            assets_proposed=0,
            assets_deployed=len(self.assets),
            opex_avoided=round(opex_avoided, 2),
            capex_invested=round(capex, 2),
            net_savings=round(opex_avoided - capex, 2),
            run_rate_before=round(run_rate_before, 2),
            run_rate_after=round(run_rate_after, 2),
            efficiency_score=round((run_rate_before - run_rate_after) / run_rate_before * 100, 1),
            asset_library_value=round(sum(a.remaining_value for a in self.assets), 2)
        )

    def asset_depreciation_schedule(self, asset: Asset, months: int = 12) -> List[Dict]:
        """
        Generate a month-by-month depreciation schedule for a single asset.
        Straight-line depreciation over 12 months.
        """
        monthly_depreciation = asset.creation_cost / months
        schedule = []
        remaining = asset.creation_cost
        for m in range(1, months + 1):
            remaining -= monthly_depreciation
            schedule.append({
                'month': m,
                'book_value': round(max(remaining, 0), 2),
                'savings_realized': round(asset.monthly_savings, 2),
                'net_value': round(max(remaining, 0) + (asset.monthly_savings * m), 2)
            })
        return schedule
