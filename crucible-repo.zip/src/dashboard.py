"""
Crucible Dashboard Generator

Generates a self-contained, interactive HTML dashboard from Crucible data.
All charts are embedded via Chart.js CDN — no build step required.
"""

import json
from collections import defaultdict
from typing import List, Dict

from .capture import AIInteraction
from .forge import Asset
from .ledger import FoundryReport


def generate_dashboard(
    interactions: List[AIInteraction],
    assets: List[Asset],
    report: FoundryReport,
    output_path: str = "crucible_dashboard.html"
) -> str:
    """
    Generate an interactive HTML dashboard and save to disk.

    Returns:
        Path to the generated HTML file.
    """
    # Aggregate data
    dept_spend = defaultdict(float)
    model_spend = defaultdict(float)
    task_spend = defaultdict(float)
    daily_spend = defaultdict(float)
    user_spend = defaultdict(float)

    for inter in interactions:
        dept_spend[inter.department] += inter.cost_usd
        model_spend[inter.model] += inter.cost_usd
        task_spend[inter.task_type] += inter.cost_usd
        day_key = inter.timestamp.strftime('%Y-%m-%d')
        daily_spend[day_key] += inter.cost_usd
        user_spend[inter.user_name] += inter.cost_usd

    daily_labels = sorted(daily_spend.keys())
    daily_values = [round(daily_spend[d], 2) for d in daily_labels]

    top_users = sorted(user_spend.items(), key=lambda x: x[1], reverse=True)[:10]

    asset_data = []
    for a in assets:
        asset_data.append({
            'id': a.id,
            'name': a.name,
            'type': a.asset_type,
            'task': a.task_type,
            'dept': a.department,
            'creation_cost': a.creation_cost,
            'monthly_savings': a.monthly_savings,
            'payback_days': a.payback_days,
            'remaining_value': a.remaining_value,
            'utilization': round(a.utilization_rate * 100, 1),
            'calls_handled': a.total_calls_handled,
            'status': a.status
        })

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Crucible — AI Capitalization Dashboard</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
:root {{
  --bg: #0f1117;
  --card: #161922;
  --card-hover: #1c1f2a;
  --border: #2a2e3b;
  --text: #e2e4e9;
  --text-muted: #8b92a8;
  --accent: #00d4aa;
  --accent-2: #ff6b6b;
  --accent-3: #4ecdc4;
  --accent-4: #ffe66d;
  --success: #2ecc71;
  --warning: #f39c12;
}}
* {{ margin: 0; padding: 0; box-sizing: border-box; }}
body {{
  background: var(--bg);
  color: var(--text);
  font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
  line-height: 1.5;
}}
.container {{ max-width: 1400px; margin: 0 auto; padding: 24px; }}
header {{
  display: flex; justify-content: space-between; align-items: center;
  padding-bottom: 24px; border-bottom: 1px solid var(--border); margin-bottom: 24px;
}}
header h1 {{ font-size: 1.8rem; font-weight: 700; letter-spacing: -0.5px; }}
header h1 span {{ color: var(--accent); }}
.badge {{
  background: var(--card); border: 1px solid var(--border); padding: 6px 14px;
  border-radius: 20px; font-size: 0.85rem; color: var(--text-muted);
}}
.badge.live {{ border-color: var(--success); color: var(--success); }}
.kpi-grid {{
  display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 16px; margin-bottom: 24px;
}}
.kpi-card {{
  background: var(--card); border: 1px solid var(--border); border-radius: 12px;
  padding: 20px; transition: transform 0.2s, border-color 0.2s;
}}
.kpi-card:hover {{ transform: translateY(-2px); border-color: var(--accent); }}
.kpi-card .label {{ font-size: 0.8rem; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 8px; }}
.kpi-card .value {{ font-size: 2rem; font-weight: 700; margin-bottom: 4px; }}
.kpi-card .sub {{ font-size: 0.85rem; color: var(--text-muted); }}
.kpi-card .sub.positive {{ color: var(--success); }}
.kpi-card .sub.negative {{ color: var(--accent-2); }}
.kpi-card.accent {{ border-left: 3px solid var(--accent); }}
.kpi-card.accent-2 {{ border-left: 3px solid var(--accent-2); }}
.kpi-card.accent-3 {{ border-left: 3px solid var(--accent-3); }}
.kpi-card.accent-4 {{ border-left: 3px solid var(--accent-4); }}
.chart-grid {{
  display: grid; grid-template-columns: 2fr 1fr;
  gap: 16px; margin-bottom: 24px;
}}
.chart-card {{
  background: var(--card); border: 1px solid var(--border); border-radius: 12px;
  padding: 20px;
}}
.chart-card h3 {{ font-size: 1rem; margin-bottom: 16px; color: var(--text-muted); font-weight: 600; }}
.chart-container {{ position: relative; height: 280px; }}
.table-card {{
  background: var(--card); border: 1px solid var(--border); border-radius: 12px;
  padding: 20px; margin-bottom: 24px; overflow-x: auto;
}}
.table-card h3 {{ font-size: 1rem; margin-bottom: 16px; color: var(--text-muted); font-weight: 600; }}
table {{
  width: 100%; border-collapse: collapse; font-size: 0.9rem;
}}
th {{ text-align: left; padding: 10px 12px; color: var(--text-muted); font-weight: 600; border-bottom: 1px solid var(--border); }}
td {{ padding: 10px 12px; border-bottom: 1px solid var(--border); color: var(--text); }}
tr:hover td {{ background: var(--card-hover); }}
.tag {{
  display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 0.75rem;
  font-weight: 600; text-transform: uppercase;
}}
.tag.template {{ background: rgba(0,212,170,0.15); color: var(--accent); }}
.tag.script {{ background: rgba(78,205,196,0.15); color: var(--accent-3); }}
.tag.micro_model {{ background: rgba(255,107,107,0.15); color: var(--accent-2); }}
.tag.workflow {{ background: rgba(255,230,109,0.15); color: var(--accent-4); }}
.tag.deployed {{ background: rgba(46,204,113,0.15); color: var(--success); }}
.concept {{
  background: linear-gradient(135deg, rgba(0,212,170,0.08), rgba(78,205,196,0.05));
  border: 1px solid var(--accent); border-radius: 12px; padding: 24px; margin-bottom: 24px;
}}
.concept h2 {{ font-size: 1.3rem; margin-bottom: 12px; color: var(--accent); }}
.concept p {{ color: var(--text-muted); line-height: 1.7; }}
.concept .highlight {{ color: var(--text); font-weight: 600; }}
@media (max-width: 900px) {{
  .chart-grid {{ grid-template-columns: 1fr; }}
  .kpi-grid {{ grid-template-columns: 1fr 1fr; }}
}}
@media (max-width: 600px) {{
  .kpi-grid {{ grid-template-columns: 1fr; }}
}}
</style>
</head>
<body>
<div class="container">
  <header>
    <div>
      <h1>Crucible <span>Dashboard</span></h1>
      <p style="color: var(--text-muted); font-size: 0.9rem; margin-top: 4px;">AI Capitalization Engine — Enterprise Simulation</p>
    </div>
    <div class="badge live">● Live</div>
  </header>

  <div class="concept">
    <h2>Philosophy: Stop Renting Intelligence. Start Owning It.</h2>
    <p>
      Your team used AI <span class="highlight">{report.total_interactions:,} times</span> this month, spending <span class="highlight">${report.total_spend:,.2f}</span> on API calls.
      Crucible detected <span class="highlight">{report.captured_patterns} repeatable patterns</span> and forged them into <span class="highlight">{report.assets_deployed} permanent capital assets</span>.
      Your daily AI run rate dropped from <span class="highlight">${report.run_rate_before:,.2f}</span> to <span class="highlight">${report.run_rate_after:,.2f}</span> — a <span class="highlight">{report.efficiency_score}% efficiency gain</span>.
      The asset library now has a book value of <span class="highlight">${report.asset_library_value:,.2f}</span>.
    </p>
  </div>

  <div class="kpi-grid">
    <div class="kpi-card accent">
      <div class="label">30-Day AI Spend</div>
      <div class="value">${report.total_spend:,.2f}</div>
      <div class="sub">OpEx — consumable tokens</div>
    </div>
    <div class="kpi-card accent-2">
      <div class="label">CapEx Invested</div>
      <div class="value">${report.capex_invested:,.2f}</div>
      <div class="sub">One-time asset creation</div>
    </div>
    <div class="kpi-card accent-3">
      <div class="label">Monthly OpEx Avoided</div>
      <div class="value">${report.opex_avoided:,.2f}</div>
      <div class="sub positive">Recurring savings from assets</div>
    </div>
    <div class="kpi-card accent-4">
      <div class="label">Asset Library Value</div>
      <div class="value">${report.asset_library_value:,.2f}</div>
      <div class="sub">12-month remaining value</div>
    </div>
    <div class="kpi-card" style="border-left: 3px solid var(--success);">
      <div class="label">Efficiency Gain</div>
      <div class="value">{report.efficiency_score}%</div>
      <div class="sub positive">Run rate reduction</div>
    </div>
    <div class="kpi-card" style="border-left: 3px solid var(--warning);">
      <div class="label">Payback Period</div>
      <div class="value">{round(report.capex_invested / (report.opex_avoided / 30), 1) if report.opex_avoided > 0 else 'N/A'} days</div>
      <div class="sub">Average asset ROI</div>
    </div>
  </div>

  <div class="chart-grid">
    <div class="chart-card">
      <h3>Daily AI Spend — 30 Day Trend</h3>
      <div class="chart-container"><canvas id="dailyChart"></canvas></div>
    </div>
    <div class="chart-card">
      <h3>Spend by Department</h3>
      <div class="chart-container"><canvas id="deptChart"></canvas></div>
    </div>
  </div>

  <div class="chart-grid" style="grid-template-columns: 1fr 1fr;">
    <div class="chart-card">
      <h3>Spend by Model</h3>
      <div class="chart-container"><canvas id="modelChart"></canvas></div>
    </div>
    <div class="chart-card">
      <h3>CapEx vs OpEx Shift</h3>
      <div class="chart-container"><canvas id="capexChart"></canvas></div>
    </div>
  </div>

  <div class="table-card">
    <h3>Capital Asset Inventory — The Forge Output</h3>
    <table>
      <thead>
        <tr><th>Asset</th><th>Type</th><th>Dept</th><th>Creation Cost</th><th>Monthly Savings</th><th>Payback</th><th>Remaining Value</th><th>Utilization</th><th>Status</th></tr>
      </thead>
      <tbody>
"""

    for a in asset_data:
        html += f"""        <tr>
          <td><strong>{a['name']}</strong></td>
          <td><span class="tag {a['type']}">{a['type']}</span></td>
          <td>{a['dept']}</td>
          <td>${a['creation_cost']:,.2f}</td>
          <td style="color: var(--success);">${a['monthly_savings']:,.2f}</td>
          <td>{a['payback_days']} days</td>
          <td>${a['remaining_value']:,.2f}</td>
          <td>{a['utilization']}%</td>
          <td><span class="tag deployed">{a['status']}</span></td>
        </tr>
"""

    html += """      </tbody>
    </table>
  </div>

  <div class="chart-grid" style="grid-template-columns: 1fr 1fr;">
    <div class="chart-card">
      <h3>Top AI Users by Spend</h3>
      <div class="chart-container"><canvas id="userChart"></canvas></div>
    </div>
    <div class="chart-card">
      <h3>Task Type Distribution</h3>
      <div class="chart-container"><canvas id="taskChart"></canvas></div>
    </div>
  </div>
</div>

<script>
"""

    html += f"""
const dailyLabels = {json.dumps(daily_labels)};
const dailyValues = {json.dumps(daily_values)};
const deptLabels = {json.dumps(list(dept_spend.keys()))};
const deptValues = {json.dumps([round(v,2) for v in dept_spend.values()])};
const modelLabels = {json.dumps(list(model_spend.keys()))};
const modelValues = {json.dumps([round(v,2) for v in model_spend.values()])};
const taskLabels = {json.dumps(list(task_spend.keys()))};
const taskValues = {json.dumps([round(v,2) for v in task_spend.values()])};
const userLabels = {json.dumps([u[0] for u in top_users])};
const userValues = {json.dumps([round(u[1],2) for u in top_users])};

const chartColors = ['#00d4aa', '#ff6b6b', '#4ecdc4', '#ffe66d', '#a29bfe', '#fd79a8', '#dfe6e9', '#00b894'];
const chartGrid = '#2a2e3b';
const chartText = '#8b92a8';

const commonOptions = {{
  responsive: true,
  maintainAspectRatio: false,
  plugins: {{ legend: {{ labels: {{ color: chartText }} }} }},
  scales: {{
    x: {{ grid: {{ color: chartGrid }}, ticks: {{ color: chartText }} }},
    y: {{ grid: {{ color: chartGrid }}, ticks: {{ color: chartText }} }}
  }}
}};

new Chart(document.getElementById('dailyChart'), {{
  type: 'line',
  data: {{
    labels: dailyLabels,
    datasets: [{{
      label: 'Daily AI Spend ($)',
      data: dailyValues,
      borderColor: '#00d4aa',
      backgroundColor: 'rgba(0,212,170,0.1)',
      fill: true,
      tension: 0.4,
      pointRadius: 3
    }}]
  }},
  options: commonOptions
}});

new Chart(document.getElementById('deptChart'), {{
  type: 'doughnut',
  data: {{
    labels: deptLabels,
    datasets: [{{
      data: deptValues,
      backgroundColor: chartColors,
      borderWidth: 0
    }}]
  }},
  options: {{
    responsive: true,
    maintainAspectRatio: false,
    plugins: {{ legend: {{ position: 'right', labels: {{ color: chartText }} }} }},
    cutout: '65%'
  }}
}});

new Chart(document.getElementById('modelChart'), {{
  type: 'bar',
  data: {{
    labels: modelLabels,
    datasets: [{{
      label: 'Spend ($)',
      data: modelValues,
      backgroundColor: ['#ff6b6b', '#00d4aa', '#4ecdc4', '#ffe66d', '#a29bfe'],
      borderRadius: 6
    }}]
  }},
  options: commonOptions
}});

new Chart(document.getElementById('capexChart'), {{
  type: 'bar',
  data: {{
    labels: ['Before Crucible', 'After Crucible'],
    datasets: [
      {{
        label: 'Monthly OpEx',
        data: [{report.run_rate_before * 30:.2f}, {report.run_rate_after * 30:.2f}],
        backgroundColor: '#ff6b6b',
        borderRadius: 6
      }},
      {{
        label: 'Asset CapEx (amortized)',
        data: [0, {report.capex_invested / 12:.2f}],
        backgroundColor: '#00d4aa',
        borderRadius: 6
      }}
    ]
  }},
  options: commonOptions
}});

new Chart(document.getElementById('userChart'), {{
  type: 'bar',
  data: {{
    labels: userLabels,
    datasets: [{{
      label: '30-Day Spend ($)',
      data: userValues,
      backgroundColor: '#4ecdc4',
      borderRadius: 6
    }}]
  }},
  options: commonOptions
}});

new Chart(document.getElementById('taskChart'), {{
  type: 'polarArea',
  data: {{
    labels: taskLabels.map(t => t.replace('_', ' ')),
    datasets: [{{
      data: taskValues,
      backgroundColor: chartColors.map(c => c + '88'),
      borderColor: chartColors,
      borderWidth: 1
    }}]
  }},
  options: {{
    responsive: true,
    maintainAspectRatio: false,
    plugins: {{ legend: {{ position: 'right', labels: {{ color: chartText }} }} }},
    scales: {{ r: {{ grid: {{ color: chartGrid }}, ticks: {{ color: chartText, backdropColor: 'transparent' }} }} }}
  }}
}});
</script>
</body>
</html>
"""

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(html)

    return output_path
