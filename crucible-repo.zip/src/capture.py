"""
The Crucible — Forensic AI Interaction Capture

Intercepts and catalogs every AI interaction across the enterprise with
sufficient granularity to detect patterns, audit usage, and classify tasks.
"""

import datetime
from dataclasses import dataclass
from typing import List, Dict
from collections import defaultdict


@dataclass
class AIInteraction:
    """A single atomic AI interaction."""
    id: str
    timestamp: datetime.datetime
    user_id: str
    user_name: str
    department: str
    task_type: str
    model: str
    input_tokens: int
    output_tokens: int
    cost_usd: float
    prompt_summary: str
    output_accepted: bool
    context_hash: str


class InteractionCapture:
    """
    The Crucible. Ingests every AI interaction and provides query interfaces
    for pattern detection across users, departments, and task types.
    """

    def __init__(self):
        self.interactions: List[AIInteraction] = []
        self._by_user: Dict[str, List[AIInteraction]] = defaultdict(list)
        self._by_task: Dict[str, List[AIInteraction]] = defaultdict(list)
        self._by_dept: Dict[str, List[AIInteraction]] = defaultdict(list)

    def ingest(self, interaction: AIInteraction) -> None:
        """Ingest a single interaction and index it."""
        self.interactions.append(interaction)
        self._by_user[interaction.user_id].append(interaction)
        self._by_task[interaction.task_type].append(interaction)
        self._by_dept[interaction.department].append(interaction)

    def get_by_user(self, user_id: str) -> List[AIInteraction]:
        return self._by_user.get(user_id, [])

    def get_by_task(self, task_type: str) -> List[AIInteraction]:
        return self._by_task.get(task_type, [])

    def get_by_department(self, dept: str) -> List[AIInteraction]:
        return self._by_dept.get(dept, [])

    def get_by_user_task(self, user_id: str, task_type: str) -> List[AIInteraction]:
        """Get interactions for a specific user-task pair."""
        return [i for i in self._by_user.get(user_id, []) if i.task_type == task_type]

    def summary(self) -> Dict:
        """Return high-level capture statistics."""
        if not self.interactions:
            return {}
        return {
            "total_interactions": len(self.interactions),
            "total_cost": round(sum(i.cost_usd for i in self.interactions), 2),
            "unique_users": len(self._by_user),
            "unique_tasks": len(self._by_task),
            "unique_departments": len(self._by_dept),
            "date_range": (
                min(i.timestamp for i in self.interactions).isoformat(),
                max(i.timestamp for i in self.interactions).isoformat(),
            ),
        }
