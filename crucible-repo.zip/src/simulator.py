"""
Enterprise AI Usage Simulator

Generates realistic 30-day AI interaction datasets for testing and demo purposes.
Models real enterprise behavior: department task biases, model preferences,
token distributions, and human acceptance rates.
"""

import random
import datetime
from typing import Dict, List

from .capture import AIInteraction, InteractionCapture


def generate_simulation(
    days: int = 30,
    seed: int = None
) -> InteractionCapture:
    """
    Generate a realistic enterprise AI usage dataset.

    Args:
        days: Number of days to simulate (default 30)
        seed: Random seed for reproducibility

    Returns:
        InteractionCapture populated with simulated interactions
    """
    if seed is not None:
        random.seed(seed)

    capture = InteractionCapture()

    departments = ['Engineering', 'Marketing', 'Support', 'Sales', 'Legal']
    users = {
        'Engineering': ['Alice Chen', 'Bob Martinez', 'Carol White', 'David Kim',
                        'Eva Patel', 'Frank Liu', 'Grace Okafor', 'Hassan Rahman'],
        'Marketing': ['Ivan Petrov', 'Julia Santos', 'Kenji Tanaka', 'Lena Mueller', 'Mike Ross'],
        'Support': ['Nina Dobrev', 'Oscar Wilde', 'Paul Atreides', 'Quinn Fabray',
                    'Rachel Green', 'Steve Rogers'],
        'Sales': ['Tony Stark', 'Uma Thurman', 'Victor Hugo', 'Wanda Maximoff'],
        'Legal': ['Xander Cage', 'Yara Greyjoy', 'Zoe Saldana']
    }

    # Realistic pricing per 1K tokens (input + output blended)
    model_pricing = {
        'GPT-6': 0.045,
        'Claude-4': 0.038,
        'GPT-3.5': 0.0015,
        'DeepSeek': 0.00014,
        'Kimi-K2.6': 0.0010
    }

    task_profiles = {
        'email_draft': {'models': ['GPT-6', 'Claude-4'], 'tokens': (1200, 3500), 'accept_rate': 0.82},
        'ticket_classify': {'models': ['GPT-3.5', 'DeepSeek'], 'tokens': (600, 2000), 'accept_rate': 0.91},
        'data_analysis': {'models': ['GPT-6', 'Claude-4', 'Kimi-K2.6'], 'tokens': (5000, 15000), 'accept_rate': 0.75},
        'doc_summarize': {'models': ['GPT-3.5', 'DeepSeek', 'Kimi-K2.6'], 'tokens': (3000, 12000), 'accept_rate': 0.88},
        'code_review': {'models': ['GPT-6', 'Claude-4'], 'tokens': (4000, 12000), 'accept_rate': 0.68},
        'legal_review': {'models': ['GPT-6', 'Claude-4'], 'tokens': (6000, 18000), 'accept_rate': 0.79},
        'slide_generation': {'models': ['GPT-6', 'Kimi-K2.6'], 'tokens': (2500, 8000), 'accept_rate': 0.71},
        'customer_response': {'models': ['GPT-3.5', 'DeepSeek'], 'tokens': (800, 2500), 'accept_rate': 0.93}
    }

    dept_task_bias = {
        'Engineering': ['code_review', 'data_analysis', 'doc_summarize', 'email_draft'],
        'Marketing': ['slide_generation', 'email_draft', 'doc_summarize', 'data_analysis'],
        'Support': ['ticket_classify', 'customer_response', 'doc_summarize', 'email_draft'],
        'Sales': ['email_draft', 'customer_response', 'slide_generation', 'data_analysis'],
        'Legal': ['legal_review', 'doc_summarize', 'email_draft']
    }

    base_date = datetime.datetime(2026, 5, 1)
    counter = 0

    for day in range(days):
        for dept, user_list in users.items():
            for user in user_list:
                # 3-8 tasks per day per user (heavy AI adoption)
                daily_tasks = random.randint(3, 8)
                for _ in range(daily_tasks):
                    task = random.choice(dept_task_bias[dept])
                    profile = task_profiles[task]
                    model = random.choice(profile['models'])

                    in_tok = random.randint(profile['tokens'][0], profile['tokens'][1])
                    out_tok = int(in_tok * random.uniform(0.25, 0.75))
                    cost = (in_tok + out_tok) * model_pricing[model] / 1000

                    inter = AIInteraction(
                        id=f"INT-{counter:05d}",
                        timestamp=base_date + datetime.timedelta(
                            days=day,
                            hours=random.randint(8, 18),
                            minutes=random.randint(0, 59)
                        ),
                        user_id=user.replace(' ', '_').lower(),
                        user_name=user,
                        department=dept,
                        task_type=task,
                        model=model,
                        input_tokens=in_tok,
                        output_tokens=out_tok,
                        cost_usd=round(cost, 4),
                        prompt_summary=f"{task} #{random.randint(1, 999)}",
                        output_accepted=random.random() < profile['accept_rate'],
                        context_hash=f"ctx_{dept}_{task}_{random.randint(1000, 9999)}"
                    )
                    capture.ingest(inter)
                    counter += 1

    return capture
