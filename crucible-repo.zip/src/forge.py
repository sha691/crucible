"""
The Forge — Pattern Detection & Asset Creation

Detects repeatable task signatures across captured interactions and
"forges" permanent capital assets (templates, scripts, micro-models, workflows)
that replace future API calls.
"""

import random
import datetime
from dataclasses import dataclass
from typing import List, Dict
from collections import defaultdict

from .capture import AIInteraction


@dataclass
class Asset:
    """A permanent capital asset forged from detected patterns."""
    id: str
    name: str
    asset_type: str  # template, script, micro_model, workflow
    task_type: str
    department: str
    created_from_interactions: List[str]
    creation_cost: float
    replaces_task_type: str
    estimated_daily_calls_replaced: int
    avg_cost_per_call_before: float
    monthly_savings: float
    payback_days: float
    remaining_value: float
    status: str
    created_at: datetime.datetime
    utilization_rate: float = 0.0
    total_calls_handled: int = 0


class DistillationEngine:
    """
    The Forge. Analyzes captured interactions for repeatable patterns and
    proposes or deploys capital assets with full ROI calculations.
    """

    # Task signature configuration:
    # threshold = min interactions to qualify as pattern
    # asset_type = what kind of asset to forge
    # forge_cost = base engineering cost to create the asset
    TASK_SIGNATURES = {
        'email_draft': {'threshold': 8, 'asset_type': 'template', 'forge_cost': 45.0},
        'ticket_classify': {'threshold': 10, 'asset_type': 'script', 'forge_cost': 85.0},
        'data_analysis': {'threshold': 6, 'asset_type': 'script', 'forge_cost': 120.0},
        'doc_summarize': {'threshold': 8, 'asset_type': 'template', 'forge_cost': 35.0},
        'code_review': {'threshold': 12, 'asset_type': 'micro_model', 'forge_cost': 340.0},
        'legal_review': {'threshold': 6, 'asset_type': 'micro_model', 'forge_cost': 280.0},
        'slide_generation': {'threshold': 6, 'asset_type': 'template', 'forge_cost': 65.0},
        'customer_response': {'threshold': 10, 'asset_type': 'workflow', 'forge_cost': 95.0},
    }

    def __init__(self, capture):
        self.capture = capture
        self.patterns: Dict[str, Dict] = {}
        self.assets: List[Asset] = []

    def detect_patterns(self) -> Dict[str, Dict]:
        """
        Scan all captured interactions and group by (department, task_type).
        If a group exceeds the task threshold, it qualifies as a forgeable pattern.
        """
        task_groups = defaultdict(list)
        for inter in self.capture.interactions:
            key = f"{inter.department}:{inter.task_type}"
            task_groups[key].append(inter)

        patterns = {}
        for key, interactions in task_groups.items():
            dept, task = key.split(':')
            if task not in self.TASK_SIGNATURES:
                continue
            sig = self.TASK_SIGNATURES[task]
            if len(interactions) >= sig['threshold']:
                avg_cost = sum(i.cost_usd for i in interactions) / len(interactions)
                accepted_rate = sum(1 for i in interactions if i.output_accepted) / len(interactions)
                patterns[key] = {
                    'department': dept,
                    'task_type': task,
                    'frequency': len(interactions),
                    'avg_cost_per_call': avg_cost,
                    'total_spent': sum(i.cost_usd for i in interactions),
                    'acceptance_rate': accepted_rate,
                    'interactions': interactions,
                    'recommended_asset': sig['asset_type'],
                    'forge_cost': sig['forge_cost']
                }
        self.patterns = patterns
        return patterns

    def forge_assets(self, deploy_all: bool = True) -> List[Asset]:
        """
        Convert detected patterns into capital assets with full economic modeling.

        Economics:
        - creation_cost = base forge cost + 20% of historical pattern spend (design iterations)
        - asset_runtime_cost = ~2% of original API cost (self-hosted inference / script execution)
        - monthly_savings = 80% of calls replaced * (original_cost - runtime_cost) * 30 days
        - payback = creation_cost / (monthly_savings / 30)
        - remaining_value = 12 months of projected savings
        """
        assets = []
        for key, pattern in self.patterns.items():
            dept = pattern['department']
            task = pattern['task_type']
            sig = self.TASK_SIGNATURES[task]

            daily_freq = pattern['frequency'] / 30
            creation_cost = sig['forge_cost'] + (pattern['total_spent'] * 0.20)
            asset_runtime_cost = pattern['avg_cost_per_call'] * 0.02
            monthly_savings = daily_freq * 30 * (pattern['avg_cost_per_call'] - asset_runtime_cost) * 0.80
            payback = creation_cost / (monthly_savings / 30) if monthly_savings > 0 else 999

            asset = Asset(
                id=f"AST-{len(assets)+1001}",
                name=f"{dept} {task.replace('_', ' ').title()} Auto",
                asset_type=sig['asset_type'],
                task_type=task,
                department=dept,
                created_from_interactions=[i.id for i in pattern['interactions'][:5]],
                creation_cost=round(creation_cost, 2),
                replaces_task_type=task,
                estimated_daily_calls_replaced=int(daily_freq * 0.80),
                avg_cost_per_call_before=round(pattern['avg_cost_per_call'], 4),
                monthly_savings=round(monthly_savings, 2),
                payback_days=round(payback, 1),
                remaining_value=round(monthly_savings * 12, 2),
                status='deployed' if deploy_all else 'proposed',
                created_at=datetime.datetime.now(),
                utilization_rate=random.uniform(0.82, 0.97) if deploy_all else 0.0,
                total_calls_handled=int(daily_freq * 30 * 0.80) if deploy_all else 0
            )
            assets.append(asset)
        self.assets = assets
        return assets

    def get_pattern_summary(self) -> List[Dict]:
        """Return a summary of detected patterns for reporting."""
        return [
            {
                'key': key,
                'department': p['department'],
                'task': p['task_type'],
                'frequency': p['frequency'],
                'total_spent': round(p['total_spent'], 2),
                'avg_cost': round(p['avg_cost_per_call'], 4),
                'acceptance': round(p['acceptance_rate'] * 100, 1),
                'asset_type': p['recommended_asset']
            }
            for key, p in self.patterns.items()
        ]
